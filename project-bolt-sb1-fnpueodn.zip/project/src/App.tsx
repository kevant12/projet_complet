import React, { useState } from 'react';

function App() {
  const [activePage, setActivePage] = useState('home');

  const pages = [
    { id: 'home', name: 'Accueil' },
    { id: 'catalog', name: 'Catalogue' },
    { id: 'product', name: 'Fiche Produit' },
    { id: 'collection', name: 'Collection' },
    { id: 'cart', name: 'Panier' },
    { id: 'checkout', name: 'Paiement' },
    { id: 'account', name: 'Espace Client' },
    { id: 'blog', name: 'Blog' },
    { id: 'grading', name: 'Service Grading' }
  ];

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex gap-2">
          {pages.map(page => (
            <button
              key={page.id}
              onClick={() => setActivePage(page.id)}
              className={`px-4 py-2 rounded ${
                activePage === page.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-white hover:bg-gray-50'
              }`}
            >
              {page.name}
            </button>
          ))}
        </div>

        <div className="bg-white p-8 rounded-lg shadow-lg">
          {activePage === 'home' && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 p-4 text-center">
                Header: Logo + Recherche + Compte + Panier
              </div>
              <div className="border-2 border-dashed border-gray-300 p-4 text-center">
                Navigation Principale
              </div>
              <div className="border-2 border-dashed border-gray-300 h-64 flex items-center justify-center">
                Bannière Slider Principale
              </div>
              <div className="grid grid-cols-4 gap-4">
                {['Cartes Unité', 'Boosters', 'Coffrets', 'Produits Dérivés'].map(cat => (
                  <div key={cat} className="border-2 border-dashed border-gray-300 aspect-square flex items-center justify-center">
                    {cat}
                  </div>
                ))}
              </div>
              <div className="border-2 border-dashed border-gray-300 p-4 text-center">
                Nouveautés & Tendances
              </div>
              <div className="border-2 border-dashed border-gray-300 p-4 text-center">
                Footer
              </div>
            </div>
          )}

          {activePage === 'catalog' && (
            <div className="grid grid-cols-4 gap-4">
              <div className="border-2 border-dashed border-gray-300 p-4">
                <div className="font-bold mb-4">Filtres</div>
                <div className="space-y-2">
                  <div>Extension ▼</div>
                  <div>Type Pokémon ▼</div>
                  <div>Rareté ▼</div>
                  <div>Prix</div>
                  <div>État</div>
                  <div>Langue</div>
                </div>
              </div>
              <div className="col-span-3 space-y-4">
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Tri et Vue
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {Array.from({ length: 9 }).map((_, i) => (
                    <div key={i} className="border-2 border-dashed border-gray-300 aspect-square flex items-center justify-center">
                      Carte {i + 1}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activePage === 'product' && (
            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 aspect-square flex items-center justify-center">
                  Image Principale
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="border-2 border-dashed border-gray-300 aspect-square"></div>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Nom du Produit</h2>
                <div className="space-y-2">
                  <div>Prix: 89,99 €</div>
                  <div>État: Mint</div>
                  <div>Disponibilité: En stock</div>
                </div>
                <button className="w-full bg-blue-600 text-white py-2 rounded">
                  Ajouter au Panier
                </button>
              </div>
            </div>
          )}

          {activePage === 'collection' && (
            <div className="space-y-8">
              <div className="grid grid-cols-3 gap-4">
                <div className="border-2 border-dashed border-gray-300 p-4 text-center">
                  Total Cartes: 758
                </div>
                <div className="border-2 border-dashed border-gray-300 p-4 text-center">
                  Valeur: 3.587,50 €
                </div>
                <div className="border-2 border-dashed border-gray-300 p-4 text-center">
                  Extensions Complètes: 3
                </div>
              </div>
              <div className="border-2 border-dashed border-gray-300 p-4">
                Sélection Extension
              </div>
              <div className="grid grid-cols-8 gap-2">
                {Array.from({ length: 24 }).map((_, i) => (
                  <div key={i} className="border-2 border-dashed border-gray-300 aspect-square"></div>
                ))}
              </div>
            </div>
          )}

          {activePage === 'cart' && (
            <div className="grid grid-cols-3 gap-8">
              <div className="col-span-2 space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="border-2 border-dashed border-gray-300 p-4 flex justify-between items-center">
                    <div>Produit {i + 1}</div>
                    <div>Prix</div>
                  </div>
                ))}
              </div>
              <div className="border-2 border-dashed border-gray-300 p-4">
                <div className="font-bold mb-4">Résumé Commande</div>
                <div className="space-y-2">
                  <div>Sous-total: 127,48€</div>
                  <div>Livraison: 4,95€</div>
                  <div>Total: 132,43€</div>
                </div>
                <button className="w-full bg-blue-600 text-white py-2 rounded mt-4">
                  Commander
                </button>
              </div>
            </div>
          )}

          {activePage === 'checkout' && (
            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Moyens de Paiement
                </div>
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Formulaire CB
                </div>
              </div>
              <div className="border-2 border-dashed border-gray-300 p-4">
                <div className="font-bold mb-4">Résumé Commande</div>
                <div className="space-y-2">
                  <div>Total: 134,42€</div>
                </div>
              </div>
            </div>
          )}

          {activePage === 'account' && (
            <div className="grid grid-cols-4 gap-8">
              <div className="space-y-2">
                <div className="font-bold">Navigation</div>
                {['Tableau de bord', 'Commandes', 'Collection', 'Paramètres'].map(item => (
                  <div key={item} className="border-2 border-dashed border-gray-300 p-2">
                    {item}
                  </div>
                ))}
              </div>
              <div className="col-span-3 space-y-4">
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Résumé Activité
                </div>
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Dernières Commandes
                </div>
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Collection
                </div>
              </div>
            </div>
          )}

          {activePage === 'blog' && (
            <div className="grid grid-cols-4 gap-8">
              <div className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Catégories
                </div>
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Archives
                </div>
              </div>
              <div className="col-span-3 space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="border-2 border-dashed border-gray-300 p-4">
                    <div className="font-bold">Titre Article {i + 1}</div>
                    <div>Extrait de l'article...</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activePage === 'grading' && (
            <div className="space-y-8">
              <div className="grid grid-cols-2 gap-4">
                <div className="border-2 border-dashed border-gray-300 aspect-video flex items-center justify-center">
                  Image Carte Gradée
                </div>
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Pourquoi Grader?
                </div>
              </div>
              <div className="grid grid-cols-4 gap-4">
                {['Envoi', 'Évaluation', 'Grade', 'Retour'].map(step => (
                  <div key={step} className="border-2 border-dashed border-gray-300 p-4 text-center">
                    {step}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Service Standard
                </div>
                <div className="border-2 border-dashed border-gray-300 p-4">
                  Service Premium
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;